﻿using System;
class MyClass
{
    private static void BubbleSort(int[] array)
    {
        for (int i = 0; i < array.Length; i++)
            for (int j = 0; j < array.Length - 1; j++)
                if (array[j] > array[j + 1])
                {
                    int t = array[j + 1];
                    array[j + 1] = array[j];
                    array[j] = t;
                }
    }

    private static void BubbleSortRev(int[] array)
    {
        for (int i = 0; i < array.Length; i++)
            for (int j = 0; j < array.Length - 1; j++)
                if (array[j] < array[j + 1])
                {
                    int t = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = t;
                }
    }

    private static int Max(int[] mass)
    {
        int max = 0;   
        for (int i = 0; i < mass.Length - 1; i++)
        {
            if (mass[i+1] > mass[i])
            {
                max = i;
            }
        }
        return max;
    }

    private static int Min(int[] mass)
    {
        int min = 50;
        for (int i = 0; i < mass.Length - 1; i++)
        {
            if (mass[i + 1] < mass[i])
            {
                min = i;
            }
        }
        return min;
    }
    static void Main()
    {
        Console.WriteLine("Введите размерность массива");
        int n = int.Parse(Console.ReadLine());
        int[] mass1 = new int[n];
        int[] mass2 = new int[n];

        Random rand = new Random();

        for (int k = 0; k <= n-1; k++)
        {
            mass1[k] = rand.Next(-50, 50);
            Console.Write(mass1[k] + ", ");
        }

        int max1 = Max(mass1);
        int min1 = Min(mass1);


        BubbleSort(mass1);

        int i = 0;

        for (int j = 0; j < mass1.Length; j++)
            if (mass1[j] > 0)
            {
                mass2[i] = mass1[j];
                i++;
            }

        BubbleSortRev(mass1);

        for (int j = 0; j < mass1.Length; j++)
            if (mass1[j] < 0)
            {
                mass2[i] = mass1[j];
                i++;
            }
        int max2 = Max(mass1);
        int min2 = Min(mass1);

        Console.WriteLine();
        for (int j = 0; j < mass2.Length; j++)
            Console.Write(mass2[j] + ", ");
        Console.WriteLine();

        Console.WriteLine("Индекс максимального элемента изменился на {0}", max2 - max1);
        Console.WriteLine("Индекс минимального элемента изменился на {0}", min1 - min2);

        Console.ReadKey();
    }
}