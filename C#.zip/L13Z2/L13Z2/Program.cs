﻿using System;

namespace L13Z2
{
    class Program
    {
        public delegate void UsingArray(string message);
        static event UsingArray Notify;
        static void Output(ConsoleKey key, char keyChar)
        {
            Notify?.Invoke($"{key} (символ '{keyChar}')");
        }

        static void Main(string[] args)
        {
            Console.Title = "Создание массива символов" ;
            Notify += DisplayMessage;
            ConsoleKeyInfo cki;
            string Str = " ";
            Console.WriteLine(" Ввод символов в массив. " + " (для прекращения ввода нажмите клавишу <F1>)\n");
            do
            {
                Console.Write("Введите символ. ");
                cki = Console.ReadKey(true);
                Console.Write("Вы нажали клавишу ");
                Output(cki.Key, cki.KeyChar);
                Str += cki.KeyChar;
            }  
            while (cki.Key != ConsoleKey.F1);
            Console.WriteLine("Массив символов: " +Str);
        }

        private static void DisplayMessage(string message)
        {
            Console.WriteLine(message);
        }
    }
}
