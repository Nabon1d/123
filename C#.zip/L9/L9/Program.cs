﻿using System;

namespace L9
{
    public class Triangle
    {
        public int a, b, c;

        public Triangle(int a, int b, int c)
        {
            this.a = a;
            this.b = b;
            this.c = c;
        }

        public void Show()
        {
            Console.WriteLine("Треугольник со сторонами {0}, {1}, {2}", a, b, c);
        }

        public void Perimeter()
        {
            float P = a + b + c;
            Console.WriteLine("Периметр треугольника {0}", P);
        }

        public void Square()
        {
            double P = (a + b + c) / 2.0;
            double S = Math.Sqrt(P * (P - a) * (P - b) * (P - c));
            Console.WriteLine("Площадь треугольника {0:f1}", S);
        }

        public bool IsTriangle
        {
            get
            {
                if (a + b > c && a + c > b && b + c > a)
                {
                    return true;
                }
                return false;
            }
        }

        public int A
        {
            get => a;
            set => a = value;
        }

        public int B
        {
            get => b;
            set => b = value;
        }

        public int C
        {
            get => c;
            set => c = value;
        }

        public int this[int i]
        {
            get
            {
                if (i == 0)
                {
                    return a;
                }
                else if (i == 1)
                {
                    return b;
                }
                else if (i == 2)
                {
                    return c;
                }
                else
                {
                    Console.WriteLine("Индекс {0} является недействительным", i);
                    return 0;
                }
            }
        }

        public static Triangle operator ++(Triangle side) => new Triangle(++side.a, ++side.b, ++side.c);
        public static Triangle operator --(Triangle side) => new Triangle(--side.a, --side.b, --side.c);
        public static bool operator true(Triangle side) => side.IsTriangle;
        public static bool operator false(Triangle side) => side.IsTriangle;
        public static Triangle operator *(Triangle side, int Scalar) => new Triangle(side.a * Scalar, side.b * Scalar, side.c * Scalar);
    }
    class Program
    {
        static void Main(string[] args)
        {
            Triangle tr = new Triangle(3, 4, 5);
            tr.Show();
            tr.Perimeter();
            tr.Square();
            Console.WriteLine(tr.IsTriangle);
            tr.A = 2;
            tr.B = 3;
            tr.C = 4;
            tr.Show();
            tr.Perimeter();
            tr.Square();
            Console.WriteLine(tr.IsTriangle);
            ++tr;
            tr.Show();
            --tr;
            tr.Show();
            Console.WriteLine(tr[0]);
            Console.WriteLine(tr[1]);
            Console.WriteLine(tr[2]);
            Console.WriteLine(tr[3]);
            tr *= 5;
            tr.Show();
        }
    }
}
