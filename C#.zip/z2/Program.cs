﻿using System;

namespace z2
{
    delegate void Changing();

    class EventClass
    {
        public event Changing ChangeName;

        public void OnChange()
        {
            if (ChangeName != null)
            {
                ChangeName();
            }
        }
    }

    class WriteInf
    {
        public void PrintName1()
        {
            Console.WriteLine("Название изменилось!");
        }
        public void PrintName2()
        {
            Console.WriteLine("Название не изменилось!");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            string nameAuto = "BMW";
            EventClass ev = new EventClass();
            WriteInf wr = new WriteInf();

            Console.WriteLine("Название автомобиля: {0}", nameAuto);

            Console.WriteLine("Изменить название автомобиля? Y - да; Остальные символы - нет");
            ConsoleKeyInfo cki;
            cki = Console.ReadKey(true);
            if (cki.Key == ConsoleKey.Y)
            {
                Console.Write("Введите новое название: ");
                string newName = Console.ReadLine();
                nameAuto = newName;
                ev.ChangeName += new Changing(wr.PrintName1);
                ev.OnChange();
            }
            else
            {
                ev.ChangeName += new Changing(wr.PrintName2);
                ev.OnChange();
            }

            Console.WriteLine("Название автомобиля: {0}", nameAuto);
        }
    }
}