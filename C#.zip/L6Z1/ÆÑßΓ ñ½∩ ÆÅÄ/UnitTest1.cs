﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using ConsoleApplication2;

namespace Тест_для_ТПО
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
