﻿using System;

namespace L6Z1
{
    class Program
    {
        static bool HasAlphabeticalOrder(string text)
        {
            // запятые и пробелы предусматриваю на всякий случай
            text = text.Trim(new char[] { ' ', '.', ',' });
            for (int i = 1; i < text.Length; i++)
            {
                // если текущий символ не больше предыдущего то буквы расположены не по алфавиту
                if (text[i - 1] >= text[i])
                {
                    return false;
                }
            }
            return true;
        }

        static void Main()
        {
            Console.WriteLine("Введите текст");
            string text = Console.ReadLine();
            Console.WriteLine("{0} по алфавиту? {1}", text, HasAlphabeticalOrder(text));
        }
    }
}
