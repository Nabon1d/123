﻿using System;
using System.Text;
using System.Collections.Generic;

namespace Лаба
{
    class MainClass
    {



        public static void Main(string[] args)
        {

            string s = "За последние 10 лет открыто 3; новых производства: 2004 -пазогребневых гипсовых плит, 2008 -сухих строительных смесей, 2013- гипсовых плит евростандарта. На ;сегодняшний день сухие строительные смеси марки ";
            List<string> listString = new List<string>();

            int count = 0;
            int last, first;
            first = 0;
            for (var i = 0; i < s.Length; i++)
            {
                if (s[i] == ';' || count == 30)
                {
                    last = i;
                    listString.Add(s.Substring(first, last - first + 1));
                    first = last;
                    count = 0;
                }
                else if (s[i] != ' ' && s[i] != ',' && s[i] != '.' && s[i] != '!' && s[i] != '?') count++;

            }

            foreach (var a in listString)
            {
                Console.WriteLine(a);
            }

            Console.ReadKey();
        }

    }
}