﻿using System;

namespace laba_8

{

    class Program

    {

        struct Patient

        {

            public string Name, surname, lastName, NumberHome;
            public float numberCard;


            public void info()

            {

                Console.WriteLine("Фамилия: {0}. Имя - {1}. Отчество - {2}.Год рождения - {3}. Зароботная плата - {4}.", surname, Name, lastName, NumberHome, numberCard);//вывод текста на экран

            }

        }

        static void Main(string[] args)

        {

            Console.Write("Введите количество сотрудников: ");//вывод текста на экран

            int n = int.Parse(Console.ReadLine());//ввод данных

            Patient[] infor = new Patient[n]; // объявление структуры и её описание

            Console.WriteLine("Заполним информацию про сотрудников:");

            for (int i = 0; i < n; i++) //объявление цикла

            {

                Console.WriteLine((i + 1) + " Сотрудник:");

                Console.Write("Фамилия:");

                infor[i].surname = Console.ReadLine();

                Console.Write("Имя:");

                infor[i].Name = Console.ReadLine(); //заполнение структуры

                Console.Write("Отчество:");

                infor[i].lastName = Console.ReadLine();

                Console.Write("Год рождения: ");
                infor[i].NumberHome = Console.ReadLine();

                Console.Write("Заработная плата:");

                infor[i].numberCard = float.Parse(Console.ReadLine());

                ;
            }

            Console.WriteLine("Информация о существующих носителях:");

            foreach (Patient inf in infor)

            {

                inf.info(); //вывод данных структуры на экран

            }

            Console.WriteLine("Введите Фамилия для удаления сотрудника:");

            string obr_Card = Console.ReadLine();

            int number = 0;

            for (int i = 0; i < n; i++)
            {
                if (infor[i].surname == obr_Card) { number = i; Console.WriteLine("Успешно удален"); }//проверка условия совпадения

            }

            for (int i = number; i < n - 1; i++)

            {
                infor[i] = infor[i + 1];


            }


            Console.Write("Введите количество элементов, которое нужно добавить: ");

            int k = int.Parse(Console.ReadLine());

            Array.Resize(ref infor, n + k - 1);



            Console.WriteLine("Заполним информацию сотрудника:");

            for (int i = n - 1; i < infor.Length; i++)

            {

                Console.WriteLine((i + 1) + " Сотрудник:");

                Console.Write("Фамилия:");

                infor[i].surname = Console.ReadLine();

                Console.Write("Имя:");

                infor[i].Name = Console.ReadLine();

                Console.Write("Отчество:");

                infor[i].lastName = Console.ReadLine();

                Console.Write("Год рождения: ");
                infor[i].NumberHome = Console.ReadLine();

                Console.Write("Зароботная плата:");

                infor[i].numberCard = float.Parse(Console.ReadLine());

            }
            foreach (Patient inf in infor)

            {

                inf.info();

            }

        }

    }

}