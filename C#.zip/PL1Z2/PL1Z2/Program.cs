﻿using System;

namespace PL1Z2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите число X");
            double x = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Введите число Y");
            double y = double.Parse(Console.ReadLine());
            double a = (3 + Math.Exp(1)) / (1 + Math.Pow(x, 2));
            double b = 1 + Math.Pow(x, 3) + ((Math.Pow(Math.Abs(y - x), 3)) / 3);
            Console.WriteLine("Функцмя A = {0:f2}. Функция B = {1:f2}", a, b);
        }
    }
}
