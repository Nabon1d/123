﻿using System;

namespace Laba13_14Z3
{
    class nazvanie
    {
        public nazvanie(string s)
        {
            string S = s;
        }
        public void Put(string s)
        {
            Console.WriteLine("Введите название авто");
            string s = Console.ReadLine();
        }
        public void Take(string s)
        {
            if (S == s)
            {
                Console.WriteLine("Название не изменилось");
            }
        }
        static void Main(string[] args)
        {

        }
    }
}