﻿using System;

namespace L4Z1
{
    public class Program
    {
        public static int Max(int x, int y)
        {
            if (x<y)
            {
               return y;
            }
            else
            {
               return x;
            }
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Введите чило 1");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите чило 2");
            int b = int.Parse(Console.ReadLine());
            int z = Max(a, ((2*b) - a)) + Max(((5*a) + (3*b)), b);
            Console.WriteLine("Максимальное число {0}", z);
        }
    }
}
