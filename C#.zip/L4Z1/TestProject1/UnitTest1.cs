using Microsoft.VisualStudio.TestTools.UnitTesting;
using L4Z1;

namespace TestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            int a = 5, b = 5, expected = 5;
            int actual = Program.Max(a, b);
            Assert.AreEqual(expected, actual);
        }
    }
}
