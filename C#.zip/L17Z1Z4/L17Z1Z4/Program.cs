﻿using System;
using System.Collections.Generic;

namespace lab17_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите строку");
            string input_text = Console.ReadLine();
            Stack<char> text = new Stack<char>();
            foreach (var i in input_text)
            {
                if (i == '#')
                {
                    if (text.Count > 0)
                        text.Pop();
                }
                else
                {
                    text.Push(i);
                }
            }

            var array = text.ToArray();
            Array.Reverse(array);
            string edited_text = new string(array);
            Console.WriteLine(edited_text);
        }
    }
}