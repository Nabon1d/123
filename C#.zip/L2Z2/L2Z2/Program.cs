﻿using System;

namespace L2Z2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите координату X вашей точки");
            float x = float.Parse(Console.ReadLine());
            Console.WriteLine("Введите координату Y вашей точки");
            float y = float.Parse(Console.ReadLine());
            if (x >= 0)
            {
                if ((y >= 0) && (y <= x + 2) && (x <= 2))
                {
                    if ((y > 0) && (y < x + 2) && (x < 2))
                    { 
                        Console.WriteLine("Да"); 
                    }
                    else 
                    { 
                        Console.WriteLine("На границе"); 
                    }
                }
                else 
                { 
                    Console.WriteLine("Нет"); 
                }
            }
            else
            {
                if ((y >= 0) && (y <= x + 2) && (x >= -2))
                {
                    if ((y > 0) && (y < x + 2) && (x < 2))
                    { 
                        Console.WriteLine("Да"); 
                    }
                    else 
                    { 
                        Console.WriteLine("На границе"); 
                    }
                }
                else 
                { 
                    Console.WriteLine("Нет"); 
                }
            }
        }
    }
}
