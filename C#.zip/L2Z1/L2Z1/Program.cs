﻿using System;

namespace L2Z1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите значение X");
            double x = double.Parse(Console.ReadLine());
            double y;
            if ((x != 1) && (x != -1))
            {
                y = (1 / (Math.Pow(x, 2) - 1));
                Console.WriteLine("Y = {0}", y);
            }
            else
            {
                Console.WriteLine("Недопустимое значение. Деление на 0");
            }
        }
    }
}
