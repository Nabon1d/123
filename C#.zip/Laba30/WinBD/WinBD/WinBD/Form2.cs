﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinBD
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "бДDataSet.Студенты". При необходимости она может быть перемещена или удалена.
            this.студентыTableAdapter.Fill(this.бДDataSet.Студенты);

        }

        DataView СтудентыDataView;

        private void button1_Click(object sender, EventArgs e)
        {
            // Загрузка таблицы данными: 
            студентыTableAdapter.Fill(бДDataSet.Студенты);
            // Настройка объекта DataView 
            СтудентыDataView = new
            DataView(бДDataSet.Студенты);
            // Настройка dataGridView для отображения данных
            dataGridView1.DataSource = СтудентыDataView;
            // Присвоения исходного порядка сортировки
            СтудентыDataView.Sort = "Фамилия";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            oleDbDataAdapter1.Update(бДDataSet);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            СтудентыDataView.Sort = SortTextBox.Text;
            СтудентыDataView.RowFilter = FilterTextBox.Text;
        }

        private void oleDbConnection1_InfoMessage(object sender, System.Data.OleDb.OleDbInfoMessageEventArgs e)
        {

        }
    }
}
