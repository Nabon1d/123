﻿using System;
using System.Text;

namespace L6Z3
{
    class Program
    {
        static char[] splitter = { ' ', '[', ']', '(', ')', '{', '}', '*', ',', '.', ';', ':', '\u2026', '#', '=' };


        static void Func_3_10(String s)
        {
            Console.WriteLine("10. Вывести слова сообщения в порядке возрастания их длин.");
            Console.WriteLine("Заданная строка: '{0}' ", s);
            String[] words = s.Split(splitter);
            Object[,] w2 = new Object[2, words.Length];
            int i, j;
            int min = 0xFFFF;
            int max = 0;
            for (i = 0; i < words.Length; i++)
            {
                w2[0, i] = words[i].Length; // записываем длинну слова
                w2[1, i] = words[i];        // записываем слово
                if (words[i].Length < min)
                {
                    min = words[i].Length; // находим минимальную длинну
                }
                if (words[i].Length > max)
                {
                    max = words[i].Length; // находим максимальную длинну
                }
            }

            for (j = min; j <= max; j++)
            {
                for (i = 0; i < words.Length; i++)
                {
                    if ((int)w2[0, i] == j) // если длинна слова соответствует текущей длинне
                    {
                        Console.WriteLine("({0}) {1}", w2[0, i], w2[1, i]); // то выводим это слово
                    }
                }
            }
        }


        static void Main(string[] args)
        {
            String s;
            s = "Необходимо разделить этот текст по словам, расставив их в порядке возрастания длины";
            Func_3_10(s);
        }
    }
}
