﻿using System;

namespace PL5Z1
{
    class Array
    {
        int[] a;
        public int n;

        public Array(int k)
        {
            a = new int[k];
            this.n = k;
            int i = 0;
            int c;

            do
            {
                try
                {
                    Console.Write($"Введите элемент a[{i}]: ");
                    c = int.Parse(Console.ReadLine());
                    a[i] = c;
                    i++;
                }
                catch (Exception)
                {
                    Console.WriteLine("Введённый элемент имеет неверный формат! ");
                }

            } while (i < k);

        }

        public void Show()
        {
            foreach (int k in a)
            {
                Console.Write($"{k} ");
            }
            Console.WriteLine();
        }


        public static Array operator +(Array m1, int m2)
        {

            for (int i = 0; i < m1.n; i++)
            {
                m1.a[i] = m1.a[i] + m2;
            }
            return m1;
        }

        public static Array operator -(Array m1, int m2)
        {

            for (int i = 0; i < m1.n; i++)
            {
                m1.a[i] = m1.a[i] - m2;
            }
            return m1;
        }
    }


    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите размерность первого массива: ");
            int n = int.Parse(Console.ReadLine());

            Array V = new Array(n);

            Console.Write("Исходный первый массив: ");
            V.Show();

            Console.Write("Введите значение скаляра для сложения: ");
            int scal = int.Parse(Console.ReadLine());
            V = V + scal;
            V.Show();

            Console.Write("Введите размерность второго массива: ");
            n = int.Parse(Console.ReadLine());

            V = new Array(n);

            Console.Write("Исходный второй массив: ");
            V.Show();

            Console.Write("Введите значение скаляра для вычитания: ");
            scal = int.Parse(Console.ReadLine());
            V = V - scal;
            V.Show();
        }
    }
}
