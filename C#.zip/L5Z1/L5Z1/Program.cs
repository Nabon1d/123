﻿using System;

namespace L5Z1
{
    class Program
    {
        static int Max(int x, int y)
        {
            if (x < y)
            {
                return y;
            }
            else
            {
                return x;
            }
        }

        static void Main(string[] args)
        {
            Random rnd = new Random();
            int[] myArray;
            Console.WriteLine("Введите количество элементов массива");
            int n = int.Parse(Console.ReadLine());
            myArray = new int[n];
            for (int i = 0; i < n; i++)
            {
                myArray[i] = rnd.Next(10); 
            }
            foreach (int elem in myArray)
            {
                Console.Write(elem);
            }
            Console.WriteLine();
            int max = myArray[0];
            foreach (int elem in myArray) 
            {
                max = Max(elem, max);
            }
            for (int i = 0; i < n - 1; i++)
            {
                if (myArray[i] == max)
                {
                    Console.WriteLine("Индекс максимального элемента - {0}", i + 1);
                }
            }
            Console.WriteLine("Максимальный элемент массива - {0}", max);
        }
    }
}
