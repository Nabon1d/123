﻿using System;

namespace PL8Z1
{
    interface Ix
    {
        void IxF0(double w);
        void IxF1();
    }

    interface Iy
    {
        void F0(double w);
        void F1();
    }

    interface Iz
    {
        void F0(double w);
        void F1();
    }

    class MyClass : Ix, Iy, Iz
    {
        public double w;

        public MyClass(double _w)
        {
            this.w = _w;
        }

        public void IxF0(double w)
        {
            Console.WriteLine(Math.Cos(w));
        }

        public void IxF1()
        {
            Console.WriteLine(Math.Cos(w));
        }

        public void F0(double w)
        {
            Console.WriteLine(Math.Exp(w));
        }

        public void F1()
        {
            Console.WriteLine(Math.Exp(w));
        }

        void Iz.F0(double w)
        {
            Console.WriteLine(1 / Math.Exp(w));
        }

        void Iz.F1()
        {
            Console.WriteLine(1 / Math.Exp(w));
        }

        public void F_0(double w)
        {
            Iz a_ob;
            a_ob = this;
            a_ob.F0(w);
        }

        public void F_1()
        {
            Iz b_ob;
            b_ob = this;
            b_ob.F1();
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            MyClass ob = new MyClass(4);
            Console.WriteLine("Вызов метода IxF0(double w)");
            ob.IxF0(3);
            Console.WriteLine("Вызов метода IxF1()");
            ob.IxF1();
            Console.WriteLine("Вызов метода, заданного неявно F0(double w)");
            ob.F0(3);
            Console.WriteLine("Вызов метода, заданного неявно F1()");
            ob.F1();
            Console.WriteLine("Вызов методв, заданного явно F0(double w)");
            ob.F_0(3);
            Console.WriteLine("Вызов методв, заданного явно F1");
            ob.F_1();
        }
    }
}
