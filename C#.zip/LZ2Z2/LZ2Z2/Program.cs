﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace lab17_3
{
    class Program
    {
        static void Main(string[] args)
        {
            string glasnie = "ауоыиэяюёе";

            Queue Q = new Queue();

            StreamReader f = new StreamReader(@"D:/text.txt");
            string[] split = f.ReadToEnd().Split();
            Console.WriteLine("Исходный текст\n");
            foreach (string s in split)
            {
                Console.Write(s + " ");
                Q.Enqueue(s);
            }
            Console.WriteLine("\n\nЭлементы, начинающиеся с гласной буквы \n");
            foreach (string str in Q)
            {
                if (str != "" && str != " ")
                {
                    if (glasnie.Contains(str.Substring(0, 1).ToLower()))
                    {
                        Console.Write(str + " ");
                    }
                }
            }

            Console.WriteLine("\n\nЭлементы, начинающиеся с согласной буквы\n");
            foreach (string str in Q)
            {
                if (str != "" && str != " ")
                {
                    if (glasnie.Contains(str.Substring(0, 1).ToLower()) == false)
                    {
                        Console.Write(str + " ");
                    }
                }
            }
            Console.ReadLine();
        }
    }
}