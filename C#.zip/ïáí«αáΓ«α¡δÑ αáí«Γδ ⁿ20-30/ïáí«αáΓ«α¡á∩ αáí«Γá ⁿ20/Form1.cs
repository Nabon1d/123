﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using System.Media;

namespace laba20
{
    public partial class Form1 : Form
    {
        PointF posB = new PointF();
        float R = 100;
        PointF Center = new PointF(900, 900);
        float Ang = 0f;
        float RotAng = 0f;

        public Form1()
        {
            InitializeComponent();
            var t = new Timer();
            t.Interval = 50;
            t.Enabled = true;
            t.Tick += (s, o) => { MoveB(); };


        }
        private static Point p1 = new Point(50, 10);
        private static Point p2 = new Point(70, 30);
        private static Point p3 = new Point(100, 50);
        private static Point p4 = new Point(70, 70);
        private static Point p5 = new Point(50, 90);
        private static Point p6 = new Point(70, 50);


        private static Point[] bumerang = { p1,p2,p3,p4,p5,p6};

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics paint = e.Graphics;
            SolidBrush S = new SolidBrush(Color.Brown);
            paint.TranslateTransform(posB.X / 5, posB.Y / 5);
            paint.RotateTransform(RotAng);

            paint.FillClosedCurve(S, bumerang);
           
        }

        private void MoveB()
        {
            RotAng += 20f;

            Ang += 0.1f;
            var x = Center.X + R * (float)Math.Cos(Ang);
            var y = Center.Y + R * (float)Math.Sin(Ang);
            posB = new PointF(x, y);

            Invalidate();
        }
    }
}
   
