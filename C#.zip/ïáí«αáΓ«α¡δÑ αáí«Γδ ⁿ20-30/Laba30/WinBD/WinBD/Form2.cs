﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinBD
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        DataView СтудентыDataView;
        private void button1_Click(object sender, EventArgs e)
        {
           
            // Загрузка таблицы данными: 
            студентыTableAdapter1.Fill(laba4DataSet1.Студенты);
            // Настройка объекта DataView 
            СтудентыDataView = new
            DataView(laba4DataSet1.Студенты);
            // Настройка dataGridView для отображения данных
            dataGridView1.DataSource = СтудентыDataView;
            // Присвоения исходного порядка сортировки
            СтудентыDataView.Sort = "Фамилия";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            oleDbDataAdapter1.Update(laba4DataSet1);
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
            СтудентыDataView.Sort = SortTextBox.Text;
            СтудентыDataView.RowFilter = FilterTextBox.Text;
        }
    }
}
