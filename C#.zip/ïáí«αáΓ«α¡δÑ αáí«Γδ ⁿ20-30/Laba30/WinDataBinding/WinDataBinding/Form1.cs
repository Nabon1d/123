﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinDataBinding
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            sotrBindingSourse.MoveNext();
        }
        private BindingSource sotrBindingSourse;
        private void Form1_Load(object sender, EventArgs e)
        {
            // Загрузка таблицы данными: 
            студентыTableAdapter1.Fill(laba4DataSet1.Студенты);
            // Создание BindingSource для таблицы Сотрудники: 
            sotrBindingSourse = new
            BindingSource(laba4DataSet1, "Студенты");
            // Настройка связывания для элементов TextBox: 
            FamtextBox.DataBindings.Add("Text", sotrBindingSourse, "Фамилия");
            NametextBox.DataBindings.Add("Text", sotrBindingSourse, "Имя");
            SectiontextBox.DataBindings.Add("Text", sotrBindingSourse, "Группа");
        }

        private void Previousbutton_Click(object sender, EventArgs e)
        {
            sotrBindingSourse.MovePrevious();
        }
    }
}
