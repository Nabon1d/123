﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BigArray
{
    public partial class Form1 : Form
    {
        int[,] x = new int[15, 15];
        int[,] y = new int[15, 15];
        double[,] z = new double[15, 15];
        int i, j;
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.RowCount = 15;
            dataGridView1.ColumnCount = 15;
            Random rand = new Random();
            for (i = 0; i < 15; i++)
                for (j = 0; j < 15; j++)
                    x[i, j] = rand.Next(-100, 100);
            for (i = 0; i < 15; i++)
                for (j = 0; j < 15; j++)
                    dataGridView1.Rows[i].Cells[j].Value = Convert.ToString(x[i, j]);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView2.RowCount = 15;
            dataGridView2.ColumnCount = 15;        
            Random rand = new Random();
            for (i = 0; i < 15; i++)
                for (j = 0; j < 15; j++)
                    y[i, j] = rand.Next(-100, 100);
            for (i = 0; i < 15; i++)
                for (j = 0; j < 15; j++)
                    dataGridView2.Rows[i].Cells[j].Value = Convert.ToString(y[i, j]);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dataGridView3.RowCount = 15;
            dataGridView3.ColumnCount = 15;
            for (i = 0; i < 15; i++)
                for (j = 0; j < 15; j++)
                    z[i, j] = 12 * x[i, j] - 0.85 * Math.Pow(y[i, j], 2);
            for (i = 0; i < 15; i++)
                for (j = 0; j < 15; j++)
                    dataGridView3.Rows[i].Cells[j].Value = Convert.ToString(z[i, j]);
        }
    }
}
