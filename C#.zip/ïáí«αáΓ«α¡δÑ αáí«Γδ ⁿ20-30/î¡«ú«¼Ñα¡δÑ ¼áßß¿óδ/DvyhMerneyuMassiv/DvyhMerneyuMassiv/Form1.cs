﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DvyhMerneyuMassiv
{
    public partial class Form1 : Form
    {
        double sum = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.RowCount = 12;
            dataGridView1.ColumnCount = 12;
            int[,] a = new int[12, 12];
            int i, j;
            Random rand = new Random();
            for (i = 0; i < 12; i++)
                for (j = 0; j < 12; j++)
                    a[i, j] = rand.Next(-20, 20);
            for (i = 0; i < 12; i++)
                for (j = 0; j < 12; j++)
                    dataGridView1.Rows[i].Cells[j].Value = Convert.ToString(a[i, j]);
            for (j = 0; j < 12; j++)
            {
                for (i = 0; i < 12; i++)
                    sum = sum + a[i, j];
                textBox1.Text += Convert.ToString(sum) + " ";
                sum = 0;
            }
                
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
