﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        int[] Mas = new int[30];
        double[] Mas1 = new double[30];
        double Sum = 0;
        int count = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random rand = new Random();
            richTextBox1.Text = "";
            for (int i = 0; i < 30; i++)
{
                Mas[i] = rand.Next(-50, 50);
                richTextBox1.Text += " Mas[" +Convert.ToString(i) + "] = " +Convert.ToString(Mas[i]) + Environment.NewLine;
            }
            richTextBox2.Text = "";
            for (int i = 0; i < Mas.Length; i++)
            {
                if (((Mas[i] % 5) == 0) && ((Mas[i] % 7) != 0))
                {
                    count++;
                    Sum += Mas[i];
                }

            }
            richTextBox2.Text = "Количество элементов " + Convert.ToString(count) + " Сумма элементов " + Convert.ToString(Sum) + Environment.NewLine;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
