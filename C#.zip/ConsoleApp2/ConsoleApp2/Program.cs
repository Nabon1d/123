﻿int c = (10 + 11) % 33;
Console.WriteLine(c);