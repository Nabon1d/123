﻿using System;
using System.Text.RegularExpressions;

namespace _10._2
{
    class Program
    {
        static void Main(string[] args)
        {
            string text = "Дана строка, в которой содержится осмысленное текстовое сообщение. Слова сообщения разделяются пробелами и знаками препинания. Выведите все слова заданной длины.";
            Console.WriteLine(text);
            Regex r = new Regex(@"\b(\w){5}\b",RegexOptions.IgnoreCase);
            Match words = r.Match(text);
            while (words.Success)
            {
                Console.WriteLine(words);
                words = words.NextMatch();
            }
            Console.ReadKey();
        }
    }
}
