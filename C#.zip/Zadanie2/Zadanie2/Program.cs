﻿using System;
using System.Collections;

namespace ConsoleApp1
{
    class Hall //класс залы
    {
        public string Hall_Number;
        public string Square;
        public string Seer_FIO;
        public string Floor;
        public string Status;

        public Hall(string a, string b, string c, string d, string e)
        {
            this.Hall_Number = a;
            this.Square = b;
            this.Seer_FIO = c;
            this.Floor = d;
            this.Status = e;
        }

        public void show_info()
        {
            Console.WriteLine("Номер зала: {0}, площадь зала: {1}, ФИО смотрителя: {2}, этаж: {3}, статус помещения: {4}", this.Hall_Number, this.Square, this.Seer_FIO, this.Floor, this.Status);
        }

        public string Return_data()
        {
            string str = this.Hall_Number + " " + this.Floor;
            return str;
        }
    }

    class Exibit //класс экспоната
    {
        public string Title;
        public string Code;
        public string Data;
        public string Cost;

        public Exibit(string a, string b, string c, string d)
        {
            this.Title = a;
            this.Code = b;
            this.Data = c;
            this.Cost = d;
        }

        public void show_info()
        {
            Console.WriteLine("Экспонат: {0}, код экспоната: {1}, данные владельца: {2}, стоимость: {3}", this.Title, this.Code, this.Data, this.Cost);
        }

        public string return_Title()
        {
            return this.Title;
        }
    }

    class Outline //клас для схемы размещения
    {
        public Hall hall;
        public Exibit exibit;
        public int Date;
        public int Term;

        public Outline(Hall a, Exibit b, int c, int d)
        {
            this.hall = a;
            this.exibit = b;
            this.Date = c;
            this.Term = d;
        }

        public void show_info()
        {
            Console.WriteLine("Номер зала: {0}, код экспоната: {1}, дата размещения: {2}, срок размещения: {3}", hall.Return_data(), exibit.return_Title(), Date, Term);
        }
    }
    class Program
    {
        static void exibit_menu(ref ArrayList list) //метод для меню экспонаты
        {
            int mode;
            while (true)
            {
                Console.Clear();
                mode = 0;
                Console.WriteLine("Экспонат:\n[1] Список экспонатов\n[2] Добавить экспонат\n[3] Удалить экспонат\n[4] Выход");

                try
                {
                    mode = int.Parse(Console.ReadLine());
                }
                catch
                {
                    Console.WriteLine("Введено неверное значение!");
                    Console.Write("Нажмите Enter");
                    Console.ReadLine();
                }

                switch (mode)
                {
                    case 1:
                        foreach (Exibit i in list) { i.show_info(); }
                        Console.Write("Нажмите Enter");
                        Console.ReadLine();
                        break;
                    case 2:
                        Console.WriteLine("Введите наименование, код экспоната, данные о владельце, стоимость:");
                        list.Add(new Exibit(Console.ReadLine(), Console.ReadLine(), Console.ReadLine(), Console.ReadLine()));
                        break;
                    case 3:
                        Console.WriteLine("Введите номер экспоната:");
                        try
                        {
                            mode = int.Parse(Console.ReadLine());
                            list.RemoveAt(mode - 1);
                        }
                        catch
                        {
                            Console.WriteLine("Введено неверное значение!");
                            Console.Write("Нажмите Enter");
                            Console.ReadLine();
                        }
                        break;
                    default:
                        if (mode != 4)
                        {
                            Console.WriteLine("Введено невеное значение!");
                            Console.Write("Нажмите Enter");
                            Console.ReadLine();
                        }
                        break;
                }

                if (mode == 4) { break; }
            }
        }
        static void hall_menu(ref ArrayList list) //метод для меню залы
        {
            int mode;
            while (true)
            {
                Console.Clear();
                mode = 0;
                Console.WriteLine("Залы:\n[1] Список залов\n[2] Добавить зал\n[3] Удалить зал\n[4] Выход");
                try
                {
                    mode = int.Parse(Console.ReadLine());
                }
                catch
                {
                    Console.WriteLine("Введено неверное значение!");
                    Console.Write("Нажмите Enter");
                    Console.ReadLine();
                }

                switch (mode)
                {
                    case 1:
                        foreach (Hall i in list) { i.show_info(); }
                        Console.Write("Нажмите Enter");
                        Console.ReadLine();
                        break;
                    case 2:
                        Console.WriteLine("Введите номер зала, его площадь, ФИО смотрителя, этаж, статус помещения:");
                        list.Add(new Hall(Console.ReadLine(), Console.ReadLine(), Console.ReadLine(), Console.ReadLine(), Console.ReadLine()));
                        break;
                    case 3:
                        Console.WriteLine("Введите номер пердмета:");
                        try
                        {
                            mode = int.Parse(Console.ReadLine());
                            list.RemoveAt(mode - 1);
                        }
                        catch
                        {
                            Console.WriteLine("Введено неверное значение!");
                            Console.Write("Нажмите Enter");
                            Console.ReadLine();
                        }
                        break;
                    default:
                        if (mode != 4)
                        {
                            Console.WriteLine("Введено невеное значение!");
                            Console.Write("Нажмите Enter");
                            Console.ReadLine();
                        }
                        break;
                }

                if (mode == 4) { break; }
            }
        }

        static void set_Outline(ref ArrayList main_list, ArrayList hall, ArrayList exibit) //метод для меню схемы размещения экспонатов
        {
            int mode;
            while (true)
            {
                Console.Clear();
                mode = 0;
                Console.WriteLine("Схема размещения экспонатов:\n[1] Вывести схему размещения\n[2] Соотнести экспонат и зал\n[3] Удалить соотношение\n[4] Выход");
                try
                {
                    mode = int.Parse(Console.ReadLine());
                }
                catch
                {
                    Console.WriteLine("Введено неверное значение!");
                }

                switch (mode)
                {
                    case 1:
                        foreach (Outline i in main_list) { i.show_info(); }
                        Console.Write("Нажмите Enter");
                        Console.ReadLine();
                        break;
                    case 2:
                        Console.WriteLine("Экспонаты:");
                        foreach (Hall i in hall) { i.show_info(); }
                        Console.WriteLine("\nЗалы:");
                        foreach (Exibit i in exibit) { i.show_info(); }
                        Console.WriteLine("\nВведите номер экспоната, номер зала , дату размещения, срок размещения:");
                        try
                        {
                            int a = int.Parse(Console.ReadLine());
                            int b = int.Parse(Console.ReadLine());
                            int c = int.Parse(Console.ReadLine());
                            int d = int.Parse(Console.ReadLine());
                            main_list.Add(new Outline((Hall)hall[a - 1], (Exibit)exibit[b - 1], c, d));
                        }
                        catch
                        {
                            Console.WriteLine("Введено неверное значение!");
                        }
                        break;
                    case 3:
                        Console.WriteLine("Введите номер соотношения:");
                        try
                        {
                            mode = int.Parse(Console.ReadLine());
                            main_list.RemoveAt(mode - 1);
                        }
                        catch
                        {
                            Console.WriteLine("Введено неверное значение!");
                            Console.Write("Нажмите Enter");
                            Console.ReadLine();
                        }
                        break;
                    default:
                        if (mode != 4)
                        {
                            Console.WriteLine("Введено невеное значение!");
                            Console.Write("Нажмите Enter");
                            Console.ReadLine();
                        }
                        break;
                }

                if (mode == 4) { break; }
            }
        }
        static void Main(string[] args)
        {
            ArrayList Halls = new ArrayList(); //список залов
            Halls.Add(new Hall("1", "100М^2", "Рябой Иван Владимирович", "1 эатж", "Открыто"));
            Halls.Add(new Hall("2", "120М^2", "Кормильчик Дмитрий Викторович", "2 этаж", "Открыто"));
            Halls.Add(new Hall("3", "110М^2", "Степанов Владислав Владимирович", "3 этаж", "Закрыто"));

            ArrayList Exibits = new ArrayList(); //список для экспонатов
            Exibits.Add(new Exibit("Чёрный квадрат", "177013", "Казимир Малевич", "Бесценно"));
            Exibits.Add(new Exibit("Мона Лиза", "228922", "Леонардо да Винчи", "Бесценно"));

            ArrayList OutlineList = new ArrayList(); //список для схемы
            int mode;

            while (true) //основное меню
            {
                Console.Clear();
                mode = 0;
                Console.WriteLine("Главное меню:\n[1] Экспонаты\n[2] Залы\n[3] Схема размещения\n[4] Выход");
                try
                {
                    mode = int.Parse(Console.ReadLine());
                }
                catch
                {
                    Console.WriteLine("Введено неверное значение!");
                    Console.Write("Нажмите Enter");
                    Console.ReadLine();
                }

                switch (mode)
                {
                    case 1:
                        exibit_menu(ref Exibits);
                        break;
                    case 2:
                        hall_menu(ref Halls);
                        break;
                    case 3:
                        set_Outline(ref OutlineList, Halls, Exibits);
                        break;
                    case 4:
                    default:
                        if (mode != 4)
                        {
                            Console.WriteLine("Введено невеное значение!");
                            Console.Write("Нажмите Enter");
                            Console.ReadLine();
                        }
                        break;
                }

                if (mode == 4) { break; }
            }
        }
    }
}

