﻿using System;
using System.Text;

namespace ConsoleApplication59
{
    class Program
    {
        static void Func_9(StringBuilder s)
        {
            Console.WriteLine("\n9. удаляет из строки все подстроки, состоящие из цифр;");
            Console.WriteLine("Дана строка: {0}", s);
            int i;

            for (i = 0; i < s.Length; i++)
            {
                if (Char.IsDigit(s[i])) // если два символа рядом, то считаем это подстрокой и удаляем ее
                {
                        s.Remove(i, 1); //  то нужно удалить только один символ
                        i--;
                }
            }
            Console.WriteLine("Новая строка: {0}", s);
        }

        static void Main(string[] args)
        {
            StringBuilder sb = new StringBuilder("12345abcdef67890ghijk1");
            sb.Append("12345abcdef67890ghijk1");
            Func_9(sb);
            Console.ReadKey();
        }
    }
}