﻿using System;

Random random = new Random();
int notshort = random.Next(256, 512);
byte sh;
try
{
    try
    {
        checked
        {
            sh = (byte)notshort;
        }
        Console.WriteLine(sh);
    }
    catch
    {
        Console.WriteLine("Сработал внутренний обработчик.");
        throw;
    }
}
catch
{
    Console.WriteLine("Сработал внешний обработчик.");
}
finally
{
    sh = (byte)notshort;
    Console.WriteLine(sh);
}
Console.ReadLine();