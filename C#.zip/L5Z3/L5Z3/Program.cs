﻿using System;

namespace L5Z3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Столбцов: ");
            int x = int.Parse(Console.ReadLine());
            int[,] A = new int[x, x];
            Console.WriteLine();

            Console.WriteLine("Заполни матрицу");

            for (int i = 0; i < x; i++)
            {
                for (int j = 0; j < x; j++)
                {
                    Console.Write("mas[" + i + "," + j + "]: ");
                    A[i, j] = int.Parse(Console.ReadLine());
                }
            }

            Console.WriteLine();
            for (int i = 0; i < x; i++)
            {
                for (int j = 0; j < x; j++)
                {
                    Console.Write(A[i, j] + "\t");
                }
                Console.WriteLine();
            }

            for (int i = 0; i < A.GetLength(0); i++)
            {
                for (int j = i + 1; j < A.GetLength(1); j++)
                {
                    var tmp = A[i, j];
                    A[i, j] = A[j, i];
                    A[j, i] = tmp;
                    Console.WriteLine(A);
                }
            }
            Console.WriteLine();
            for (int i = 0; i < x; i++)
            {
                for (int j = 0; j < x; j++)
                {
                    Console.Write(A[i, j] + "\t");
                }
                Console.WriteLine();
            }
        }
    }
}
