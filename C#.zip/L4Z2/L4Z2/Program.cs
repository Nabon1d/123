﻿using System;

namespace L4Z2
{
    class Program
    {
        static int Sum(int x)
        {
            int sum = 0;
            for (int i = 1; i<=x; ++i)
            {
                if (x % i == 0) sum += i;
            }
            return sum;
        }
        static void Main(string[] args)
        {
            int n = 1;
            int sum = 0;
            while (n != 0)
            {
                Console.WriteLine("Введите число (0 - выход)");
                n = int.Parse(Console.ReadLine());
                sum = Sum(n);
                Console.WriteLine("Сумма всех простых делителей введённого чисела равна {0}", sum);
            }
        }
    }
}
