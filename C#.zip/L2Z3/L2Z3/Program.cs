﻿using System;

namespace L2Z3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите номер вашей масти");
            float number = float.Parse(Console.ReadLine());
            switch (number)
            { 
            case 1: Console.WriteLine("Пики"); break;
            case 2: Console.WriteLine("Трефы"); break;
            case 3: Console.WriteLine("Бубны"); break;
            case 4: Console.WriteLine("Червы"); break;
            default: Console.WriteLine("Вы ввели неверный номер масти либо не ввели значение");break;
            }
        }
    }
}
