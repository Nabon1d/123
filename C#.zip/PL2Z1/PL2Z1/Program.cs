﻿using System;

namespace PL2Z1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите целое число");
            int Number = int.Parse(Console.ReadLine());
            if (Number > 255)
            {
                double Number_root = Math.Sqrt(Number);
                Console.WriteLine("Корень из вашего числа = {0:f2}", Number_root);
            }
            else
            {
                if ((Number > 0) && (Number < 256))
                {
                    Console.WriteLine("Символ {0} соответсвует введённому числу {1}", Convert.ToChar(Number), Number);
                }
                else
                {
                    Console.WriteLine("Введённые данные неверны");
                }
            }
        }
    }
}
