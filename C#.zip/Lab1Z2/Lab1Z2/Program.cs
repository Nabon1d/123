﻿using System;

namespace Lab1Z2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите значения X1");
            double x1 = double.Parse(Console.ReadLine());
            Console.WriteLine("Введите значения Y1");
            double y1 = double.Parse(Console.ReadLine());
            Console.WriteLine("Введите значения X2");
            double x2 = double.Parse(Console.ReadLine());
            Console.WriteLine("Введите значения Y2");
            double y2 = double.Parse(Console.ReadLine());
            double C = Math.Sqrt(Math.Pow(x2 - x1,2) + Math.Pow(y2 - y1,2));
            Console.WriteLine("Расстояние между точками равно {0}", C);
        }
    }
}
