﻿using System;

namespace PL6Z1
{
    class Worker
    {
        int p;
        string name;
        public Worker()
        {
            name = "Unknown";
            p = 0;
        }
        public Worker(int _p, string _name)
        {
            p = _p;
            name = _name;
        }
        public int GetMoney(int k)
        {
            return p * k;
        }
        public string GetName()
        {
            return name;
        }
    }

    class Engineer : Worker
    {
        int n;
        public Engineer(string _name, int _n) : base(0, _name)
        {
            n = _n;
        }
        public int GetMoney()
        {
            return n * 10;
        }
        public int GetLecturesCount()
        {
            return n;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите имя и фамилию сотрудника сотрудника");
            string name = Console.ReadLine();
            Console.WriteLine("Введите заработную плату сотрудника");
            int wage = int.Parse(Console.ReadLine());
            Worker worker1 = new Worker(wage, name);
            int cash = worker1.GetMoney(3);
            Console.WriteLine("Заработная плата сотрудника {0} после индексации составляет {1}", worker1.GetName(), cash);
            Console.WriteLine("Введите имя и фамилию сотрудника инженера");
            string name_engineer = Console.ReadLine();
            Console.WriteLine("Введите количество разработанных инженером проектов");
            int Count = int.Parse(Console.ReadLine());
            Engineer worker2 = new Engineer(name_engineer, Count);
            Console.WriteLine("Заработная плата инженера {0} после {1} разработанных проектов составляет {2}", name_engineer, worker2.GetLecturesCount(), worker2.GetMoney());
        }
    }
}
