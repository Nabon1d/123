﻿using System;

namespace L3Z2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите количество сtрок ");
            float n = float.Parse(Console.ReadLine());
            for (float i = 1; i <= n; ++i)
            {
                for (float j = 1; j <= 10; ++j)
                {
                    Console.Write("{0} ", j);
                }
                Console.WriteLine();
            }
        }
    }
}
