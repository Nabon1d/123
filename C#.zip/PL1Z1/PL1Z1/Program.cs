﻿using System;

namespace PL1Z1
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 3;
            double y = 2;
            Console.WriteLine("x: " + x);
            double b = 1;
            Console.WriteLine("y: " + y);
        }
    }
}
