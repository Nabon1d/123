﻿using System;

abstract class Transport
{
    public string name;
    public double cos;

    public virtual void Display()
    {
        Console.WriteLine("Здание: " + name);
    }

    public virtual void Cost()
    {
        Console.WriteLine("Стоимость транспорта: 0");  
    }
}

class Plane : Transport
{
    public int h;
    public int v;

    public Plane()
    {
        name = "Unknown";
        h = 0;
        v = 0;
    }

    public Plane(string _name, int _h, int _v)
    {
        this.name = _name;
        this.h = _h;
        this.v = _v;
        this.cos = 100 * h * v;
    }

    public override void Display()
    {
        Console.WriteLine("Самолёт: {0}, высота полёта: {1}, скорость полёта {2}", this.name, h, v);
    }

    public override void Cost()
    {
        Console.WriteLine("Стоимость самолёта: {0}", this.cos);
    }
}

class Ship : Transport
{
    public double k;
    public string p;

    public Ship()
    {
        name = "Unknown";
        k = 0;
        p = "Unknown";
    }

    public Ship(string _name, int _k, string _p)
    {
        this.name = _name;
        this.k = _k;
        this.p = _p;
        this.cos = 5 * Math.Pow(k, 2);
    }

    public override void Display()
    {
        Console.WriteLine("Корабль: {0}, количество пасажиров: {1}, порт приписки: {2}", this.name, k, p);
    }

    public override void Cost()
    {
        Console.WriteLine("Стоимость корабля: {0}", this.cos);
    }
}
class Program
{
    static void Main()
    {
        Transport[] arr = new Transport[5];
        double sr1 = 0, sr2 = 0;
        double qu1 = 0, qu2 = 0;
        for (var i = 0; i < 3; i++) //объекты класса самолёт
        {
            Console.WriteLine("Введите название, высоту и скорость полёта самолёта:");
            arr[i] = new Plane(Console.ReadLine(), int.Parse(Console.ReadLine()), int.Parse(Console.ReadLine()));
            arr[i].Cost();
            sr1 += arr[i].cos;
            qu1++;
        }
        Console.WriteLine("Средняя стоимость самолётов: {0}", sr1 / qu1);
        for (var i = 3; i < 5; i++) //объекты класса корабль
        {
            Console.WriteLine("Введите название, количество пасажиров и порт приписки корабля:");
            arr[i] = new Ship(Console.ReadLine(), int.Parse(Console.ReadLine()), Console.ReadLine());
            arr[i].Cost();
            sr2 += arr[i].cos;
            qu2++;
        }
        Console.WriteLine("Средняя стоимость кораблей: {0}", sr2 / qu2);
    }
}
