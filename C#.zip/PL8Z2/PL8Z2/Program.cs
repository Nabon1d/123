﻿using System;
using System.Collections.Generic;

namespace Students
{
    class Program
    {
        public interface ITable
        {
            int Result { get; set; }
            int Groupp { get; set; }
        }

        public class Student : ITable
        {
            public string Surname { get; set; }
            public string FirstName { get; set; }
            public string Patronymic { get; set; }
            public int Result { get; set; }
            public int Groupp { get; set; }

            public Student() { }
            public Student(string surname, string firstName, string patronymic,int groupp, int result)
            {
                Surname = surname;
                FirstName = firstName;
                Patronymic = patronymic;
                Result = result;
                Groupp = groupp;
            }
        }

        class CompStudent<T> : IComparer<T>
        where T : Student
        {
            // Реализуем интерфейс IComparer<T>
            public int Compare(T s1, T s2)
            {
                if (s1.Result < s2.Result)
                    return 1;
                if (s1.Result > s2.Result)
                    return -1;
                else
                    return 0;
            }
        }

        static void Main(string[] args)
        {
            List<Student> students = new List<Student> {
                                    new Student("Иванова", "Екатерина", "Семеновна",32,1),
                                    new Student("Сидорова", "Ирина", "Олеговна",33,2),
                                    new Student("Петрова", "Ольга", "Антоновна",32,3),
                                    new Student("Кузнецов", "Павел", "Викторович",31,4),
                                    new Student("Пугачев", "Егор", "Федорович",31,5),
                                    new Student("Логинов", "Петр", "Егорович",32,6),
            };

            Console.WriteLine("Исходный полный список студентов: \n");
            Console.WindowWidth = 100;
            foreach (Student a in students)
                Console.WriteLine($"Ф.И.О.: {a.Surname} {a.FirstName} {a.Patronymic}" +
                    $" оконч. забег с результатом {a.Result} . Группа: {a.Groupp}.");
            Console.WriteLine();
            Console.WriteLine(new String('-', 70));
            Console.WriteLine();

            Console.WriteLine("Список студентов (ФИО, группа): \n");
            foreach (Student a in students)
                Console.WriteLine($"{a.Surname} {a.FirstName} {a.Patronymic} учащихся в группе {a.Groupp}.");
            Console.WriteLine();
            Console.WriteLine(new String('-', 70));
            Console.WriteLine();
            //формируем список студенов, закончивших забег с определённым результатом:
            List<Student> fromresult = new List<Student>();
            Console.Write("Введите результат: ");
            int resultNumber = Convert.ToInt32(Console.ReadLine());
            foreach (Student a in students)
            {
                if (a.Result == resultNumber)
                {
                    fromresult.Add(a);
                }
            }
            fromresult.Sort();
            //выводим на консоль
            Console.WriteLine($"Список студентов (ФИО, группа), окончивших забег с результатом {resultNumber}: \n");
            foreach (Student a in fromresult)
                Console.WriteLine($"{a.Surname} {a.FirstName} {a.Patronymic} группа {a.Groupp}");
            Console.WriteLine();
            Console.WriteLine(new String('-', 70));
            Console.WriteLine();
            Console.WriteLine("Cписок студентов (ФИО, группа): \n");
            foreach (Student a in students)
                Console.WriteLine($"{a.Surname} {a.FirstName} {a.Patronymic}, группа: {a.Groupp}");
            //формируем список студенов, успешно завершивших забег (результат выше 4 места):
            CompStudent<Student> forSort = new CompStudent<Student>();
            List<Student> academicPerformance = new List<Student>();
            foreach (Student a in students)
            {
                if (a.Result <= 3)
                {
                    academicPerformance.Add(a);
                }
            }
            //сортируем полученный список
            academicPerformance.Sort(forSort);
            Console.WriteLine();
            Console.WriteLine(new String('-', 70));
            Console.WriteLine();
            //выводим на консоль
            Console.WriteLine($"Список студентов (ФИО, группа), успешно завершивших забег \n");
            foreach (Student a in academicPerformance)
                Console.WriteLine($"{a.Surname} {a.FirstName} {a.Patronymic}, группа: {a.Groupp}");
            Console.WriteLine();
            Console.WriteLine(new String('-', 70));
            Console.WriteLine();
            Console.ReadKey();
        }
    }
}