﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Lab17_4
{
    class Member
    {
        public string surname { get; set; }
        public string name { get; set; }
        public string patronymic { get; set; }
        public string sex { get; set; }
        public string age { get; set; }
        public string salary { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            string line;
            Queue<Member> all_workers = new Queue<Member>();
            StreamReader file = new StreamReader("D:/workers.txt");
            while ((line = file.ReadLine()) != null)
            {
                Member worker = new Member();
                string[] t = line.Split(',');
                worker.surname = t[0];
                worker.name = t[1];
                worker.patronymic = t[2];
                worker.sex = t[3];
                worker.age = t[4];
                worker.salary = t[5];
                all_workers.Enqueue(worker);
            }
            Console.WriteLine("Сотрудники младше 30 лет\n");
            foreach (Member member in all_workers)
                if (int.Parse(member.age.Trim()) < 30)
                    Console.WriteLine($"{member.surname}\t{member.name}\t{member.patronymic}\t{member.sex}\t{member.age}\t{member.salary}");
            Console.WriteLine("\nОстальные сотрудники\n");
            foreach (Member member in all_workers)
                if (int.Parse(member.age.Trim()) >= 30)
                    Console.WriteLine($"{member.surname}\t{member.name}\t{member.patronymic}\t{member.sex}\t{member.age}\t{member.salary}");
            Console.ReadKey();
        }
    }
}