﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;

namespace pr_3_1
{
    class Program
    {
        public static bool Vzaimno_prostie(int a, int b)
        {
            return a == b
                   ? a == 1
                   : a > b
                        ? Vzaimno_prostie(a - b, b)
                        : Vzaimno_prostie(b - a, a);
        }
        

        public static int revElem(int k, int p)
        {
            int[] x = new int[] { 1, 0, p - 1 };
            int[] y = new int[] { 0, 1, k };
            int[] t = new int[3];
            int kRev = 0;

            do
            {
                if (y[2] == 0)
                {
                    kRev = 0;
                    break;
                }
                else if (y[2] == 1)
                {
                    int q = (int)(x[2] / y[2]);
                    kRev = y[1] + q * p - 1;
                    break;
                }
                else
                {
                    int q = (int)(x[2] / y[2]);
                    for (int i = 0; i < t.Length; i++)
                    {
                        t[i] = x[i] - q * y[i];
                    }
                    x = y;
                    y = t;
                }
            } while (kRev != 0 || kRev != 1);

            return kRev;
        }

        public static int Eyler(int n)
        {
            int Your_n = n;
            for (int i = 2; i * i <= n; ++i)
                if ((n % i) == 0)
                {
                    while ((n % i) == 0)
                        n /= i;
                    Your_n -= Your_n / i;
                }
            if (n > 1) Your_n -= Your_n / n;
            return Your_n;
        }


        static void Main(string[] args)
        {
            int n = 0;
            int e = 0;
            int mCount = 0;
            List<int> me = new List<int>();
            List<int> s = new List<int>();

            int p = 0;
            int g = 0;
            int x = 0;
            int y = 0;
            int a = 0;
            int b = 0;
            int k = 0;
            int kRev = 0;
            int m = 0;

            ConsoleKeyInfo choose;
            do
            {
                Console.Clear();
                Console.WriteLine("Выберете действие:\n" +
                "(1) Вычисление ETSP\n" +
                "(2) Проверка ETSP\n" +
                "(Esc) Выход");
                choose = Console.ReadKey();
                switch (choose.Key)
                {
                    case ConsoleKey.D1:
                        Console.Clear();
                        Console.WriteLine("Выбирите действие:\n" +
                            "(1) Вычисление ETSP по алгоритму RSA\n" +
                            "(2) Вычисление ETSP по алгоритму El-Gamalya\n" +
                            "(Esc) Назад");
                        choose = Console.ReadKey();
                        switch (choose.Key)
                        {
                            case ConsoleKey.D1:
                                Console.Clear();
                                s.Clear();
                                Console.WriteLine("Введите n");
                                n = int.Parse(Console.ReadLine());
                                Console.WriteLine("Введите e");
                                e = int.Parse(Console.ReadLine());
                                int f = Eyler(n);
                                int d = revElem(e, f);
                                Console.WriteLine($"f: {f}\n" +
                                    $"d: {d}\n" +
                                    "Сколько сообщений вы хотите отправить?: ");
                                mCount = int.Parse(Console.ReadLine());
                                for (int i = 0; i < mCount; i++)
                                {
                                    Console.WriteLine("Введите сообщение: ");
                                    me.Add(int.Parse(Console.ReadLine()));
                                }
                                for (int i = 0; i < me.Count; i++)
                                {
                                    int promet = (int)(Math.Pow(me[i], e) % n);
                                    s.Add(promet);
                                }
                                Console.WriteLine($"Ваш открытый ключ: n:{n}, e:{e}\n" +
                                    $"Vashi ETSP: \n");
                                foreach (var elem in s)
                                    Console.Write(elem + " ");
                                Console.WriteLine("Нажмите любую клавишу!");
                                Console.ReadKey();
                                break;

                            case ConsoleKey.D2:
                                Console.Clear();
                                List<int> Coprime = new List<int>();
                                Console.WriteLine("Введите p");
                                p = int.Parse(Console.ReadLine());
                                Console.WriteLine("Введите g(g<p)");
                                g = int.Parse(Console.ReadLine());
                                Console.WriteLine("Введите x");
                                x = int.Parse(Console.ReadLine());
                                Console.WriteLine("Введите сообщение");
                                m = int.Parse(Console.ReadLine());

                                for (int i = 1; i <= 500; i++)
                                {
                                    if (Vzaimno_prostie(p - 1, i))
                                    {
                                        Coprime.Add(i);
                                    }
                                }

                                Console.WriteLine("Введите k");
                                k = int.Parse(Console.ReadLine());
                                kRev = revElem(k, p);

                                y = (int)(Math.Pow(g, x) % p);
                                a = (int)(Math.Pow(g, k) % p);
                                b = (int)(kRev * (m - x * a) % (p - 1));

                                Console.WriteLine($"Ваша электронно-цифровая подпись (a,b): ({a},{b})\n" +
                                    $"Ваш открытый ключ: y:{y} g:{g} p:{p}");
                                Console.WriteLine("Нажмите любую клавишу!");
                                Console.ReadKey();
                                break;

                            default:
                                break;
                        }
                        break;

                    case ConsoleKey.D2:
                        Console.Clear();
                        Console.WriteLine("Выбирете действие:\n" +
                            "(1) Проверить ETSP созданный по алгоритму RSA\n" +
                            "(2) Проверить ETSP созданный по алгоритму El-Gamalya\n" +
                            "(Esc) Nazad");
                        choose = Console.ReadKey();
                        switch (choose.Key)
                        {
                            case ConsoleKey.D1:
                                Console.Clear();
                                s.Clear();
                                Console.WriteLine("Введите n");
                                n = int.Parse(Console.ReadLine());
                                Console.WriteLine("Введите e");
                                e = int.Parse(Console.ReadLine());
                                Console.WriteLine("Сколько проверок вы желаете сделать?: ");
                                mCount = int.Parse(Console.ReadLine());
                                for (int i = 0; i < mCount; i++)
                                {
                                    Console.WriteLine("Введите ETSP: ");
                                    s.Add(int.Parse(Console.ReadLine()));
                                }
                                Console.WriteLine($"Ваши сообщения: ");
                                foreach (var elem in s)
                                    Console.Write(Math.Pow(elem, e) % n + " ");
                                Console.WriteLine("Нажмите любую клавишу!");
                                Console.ReadKey();
                                break;

                            case ConsoleKey.D2:
                                Console.Clear();
                                Console.WriteLine("Введте открытый ключ:\n" +
                                    "y: ");
                                y = int.Parse(Console.ReadLine());
                                Console.WriteLine("g: ");
                                g = int.Parse(Console.ReadLine());
                                Console.WriteLine("p: ");
                                p = int.Parse(Console.ReadLine());
                                Console.WriteLine("Введите подпись:\n" +
                                    "a: ");
                                a = int.Parse(Console.ReadLine());
                                Console.WriteLine("b: ");
                                g = int.Parse(Console.ReadLine());
                                Console.WriteLine($"Результат проверки: {Math.Pow(y, a) * Math.Pow(a, b) % p}");
                                Console.WriteLine("Нажмите любую клавишу!");
                                Console.ReadKey();
                                break;

                            default:
                                break;
                        }
                        break;

                    default:
                        break;
                }

            } while (choose.Key != ConsoleKey.Escape);


        }
    }
}
