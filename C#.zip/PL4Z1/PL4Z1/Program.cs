﻿using System;

namespace PL4Z1
{
    class Index
    {
        char[,] a;
        int g, h;

        public Index(int g, int h)
        {
            a = new char[g, h];
            this.g = g;
            this.h = h;
        }

        public int G
        {
            get
            {
                return g;
            }

            set
            {
                value = g;
            }
        }

        public int H
        {
            get
            {
                return h;
            }

            set
            {
                value = h;
            }
        }

        public void vvod()
        {
            Console.WriteLine("Заполнение матрицы");
            for (int i = 0; i < g; i++)
            {
                for (int j = 0; j < h; j++)
                {
                    Console.Write("[{0},{1}] - ", i, j);
                    a[i, j] = char.Parse(Console.ReadLine());
                }
            }

            Console.WriteLine("Исходная матрица:");

            for (int i = 0; i < g; i++)
            {
                for (int j = 0; j < h; j++)
                {
                    Console.Write(a[i, j] + " ");
                }
                Console.WriteLine();
            }
            Console.WriteLine();
        }

        public void summi()
        {

            int sumn = 0;
            int sumch = 0;

            for (int i = 0; i < g; i++)
            {
                for (int j = 0; j < h; j++)
                {
                    string k = char.ToString(a[i, j]);
                    int c = Convert.ToInt32(k);

                    if (c % 2 == 1)
                    {
                        sumn += c;
                    }
                    else if (c % 2 == 0)
                    {
                        sumch += c;
                    }

                }
                Console.WriteLine($"Сумма нечетных элементов {i}-ой строки = {sumn}");
                sumn = 0;

                Console.WriteLine($"Сумма четных элементов {i}-ой строки = {sumch}");
                sumch = 0;

                Console.WriteLine();
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Ввод размерности массива.");

                Console.Write("Введите количество строк: ");
                int N = int.Parse(Console.ReadLine());

                Console.Write("Введите количество столбцов: ");
                int M = int.Parse(Console.ReadLine());

                Index a = new Index(N, M);

                a.vvod();
                a.summi();

            }
            catch (FormatException)
            {
                Console.WriteLine("Неверный формат ввода! ");
            }

        }
    }
}