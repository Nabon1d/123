﻿using System;

namespace Lab1Z3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите двузначное число");
            int Value = int.Parse(Console.ReadLine());
            int First = Value / 10;
            int Second = Value % 10;
            int Result = (First > Second) ? Result = Second : First;
            Console.WriteLine("Наименьшая цифра в вашем двузначном числе - это {0}", Result);
        }
    }
}
