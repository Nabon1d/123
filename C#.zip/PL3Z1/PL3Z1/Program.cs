﻿using System;

namespace PL3Z1
{
    class CLinearEquation
    {
        public double arg;

        public double arg2;

        public CLinearEquation(double A, double B) { this.arg = A; this.arg2 = B; }

        public void Solve(double a, double b)

        {
            if (a == 0)
                Console.WriteLine("Корней нет");
            else
            {
                double c = -b / a;
                Console.WriteLine(c);
            }


        }
    }


    class Program
    {
        public static void Main(string[] args)
        {

            Console.WriteLine("Исходное уравнение: ax + b = 0");

            Console.Write("Введите аргумент а: ");
            double catch_a = Double.Parse(Console.ReadLine()); // 1

            Console.Write("Введите аргумент b: ");
            double catch_b = Double.Parse(Console.ReadLine()); // 1

            CLinearEquation eq = new CLinearEquation(catch_a, catch_b);

            eq.Solve(catch_a, catch_b); // Корней нет

        }
    }
}