﻿using System;

namespace PL2Z2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Вводите последовательно числа от 0 до 255, разность между ними должна быть больше 7");
            bool fact = true;
            int Buf = -7;
            while (fact == true)
            {
                int Number = int.Parse(Console.ReadLine());
                if ((Number >= 0) && (Number <= 255))
                {
                    if (Number - Buf >=7)
                    {
                        Console.WriteLine(Number);
                    }
                    else
                    {
                        if (Buf - Number >= 7)
                        {
                            Console.WriteLine(Number);
                        }
                        else
                        {
                            Console.WriteLine("Разность меньше 7");
                            break;
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Число не в диапазоне");
                    break;
                }
                Buf = Number;
            }
        }
    }
}
