﻿using System;

namespace ConsoleApplication1
{

    abstract class Function : IComparable<Function>
    {
        public abstract double A { get; set; }
        public abstract double B { get; set; }
        public abstract double Count(double x);
        public abstract int CompareTo(object a);

        public abstract Int32 CompareTo(Function obj);
    }



    class Line : Function
    {
        public sealed override Double A { get; set; }
        public sealed override Double B { get; set; }

        public Line(double a, double b)
        {
            A = a;
            B = b;
        }

        public override double Count(double x)
        {
            return A * x + B;
        }

        public override Int32 CompareTo(Function obj)
        {
            return A.CompareTo(obj.A);
        }

        public override int CompareTo(object o)
        {
            Line l = o as Line;
            if (l != null)
                return this.A.CompareTo(l.A);
            else
                throw new Exception("Невозможно сравнить два объекта");
        }
    }


    class Kub : Function
    {
        public sealed override Double A { get; set; }
        public sealed override Double B { get; set; }
        public readonly double C;

        public Kub(double a, double b, double c)
        {
            A = a;
            B = b;
            C = c;
        }

        public override double Count(double x)
        {
            return A * x * x + B * x + C;
        }

        public override Int32 CompareTo(Function obj)
        {
            return A.CompareTo(obj.A);
        }

        public override int CompareTo(object o)
        {
            Kub k = o as Kub;
            if (k != null)
                return this.A.CompareTo(k.A);
            else
                throw new Exception("Невозможно сравнить два объекта");
        }
    }



    class Hyperbola : Function
    {
        public sealed override Double A { get; set; }
        public sealed override Double B { get; set; }

        public Hyperbola(double a, double b)
        {
            A = a;
            B = b;
        }

        public override double Count(double x)
        {
            return (A / x) + B;
        }
        public override Int32 CompareTo(Function obj)
        {
            return A.CompareTo(obj.A);
        }

        public override int CompareTo(object o)
        {
            Hyperbola h = o as Hyperbola;
            if (h != null)
                return this.A.CompareTo(h.A);
            else
                throw new Exception("Невозможно сравнить два объекта");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите количество фигур");
            int n = int.Parse(Console.ReadLine());
            Function[] func = new Function[n];
            Console.WriteLine("Введите количество линий");
            int Line_count = int.Parse(Console.ReadLine());
            if (n - Line_count >= 0)
            {
                for (int i = 0; i <= Line_count - 1; i++)
                {
                    Console.WriteLine("Введите 1 точку");
                    int d1 = int.Parse(Console.ReadLine());
                    Console.WriteLine("Введите 2 точку");
                    int d2 = int.Parse(Console.ReadLine());
                    func[i] = new Line(d1, d2);
                }
            }
            else
            {
                Console.WriteLine("Слишком много");
                System.Environment.Exit(0);
            }
            
            n -= Line_count;

            Console.WriteLine("Введите количество кубов");
            int Kube_count = int.Parse(Console.ReadLine());
            if (n - Kube_count >= 0)
            {
                for (int i = 0; i <= Kube_count - 1; i++)
                {
                    Console.WriteLine("Введите 1 точку");
                    int d1 = int.Parse(Console.ReadLine());
                    Console.WriteLine("Введите 2 точку");
                    int d2 = int.Parse(Console.ReadLine());
                    Console.WriteLine("Введите 3 точку");
                    int d3 = int.Parse(Console.ReadLine());
                    func[i + Line_count] = new Kub(d1, d2, d3);
                }
            }
            else
            {
                Console.WriteLine("Слишком много");
                System.Environment.Exit(0);
            }

            n -= Kube_count;

            Console.WriteLine("Введите количество гипербол");
            int Hyper_count = int.Parse(Console.ReadLine());
            if (n - Hyper_count >= 0)
            {
                for (int i = 0; i <= Hyper_count - 1; i++)
                {
                    Console.WriteLine("Введите 1 точку");
                    int d1 = int.Parse(Console.ReadLine());
                    Console.WriteLine("Введите 2 точку");
                    int d2 = int.Parse(Console.ReadLine());
                    func[i + Line_count + Kube_count] = new Hyperbola(d1, d2);
                }
            }
            else
            {
                Console.WriteLine("Слишком много");
                System.Environment.Exit(0);
            }

            Console.WriteLine("Введите коэффициент x");
            double x = double.Parse(Console.ReadLine());
            foreach (Function f in func)
            {
                Console.WriteLine("значение функции {0} для x = {1} равно {2:f2}. Значение коэффициента A = {3}", f.GetType(), x, f.Count(x), f.A);
            }
            for (int i = 1; i < func.Length; i++)
            {
                if (func[i-1].CompareTo(func[i]) > 0)
                {
                    Console.WriteLine("Вошли в цикл");    
                    (func[i-1], func[i]) = (func[i], func[i - 1]);
                }
            }
            Console.WriteLine("Массив после сортировки");

            foreach (Function f in func)
            {
                Console.WriteLine("значение функции {0} для x = {1} равно {2:f2}. Значение коэффициента A = {3}", f.GetType(), x, f.Count(x), f.A);
            }
            Console.ReadLine();
        }
    }
}