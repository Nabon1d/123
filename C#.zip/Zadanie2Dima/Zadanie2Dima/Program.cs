﻿using System;
using System.Collections;

namespace ConsoleApp1
{
    class student //класс студент
    {
        public string third_name;
        public string sec_name;
        public string fir_name;
        public string adress;
        public string telephone;

        public student(string a, string b, string c, string d, string e)
        {
            this.third_name = a;
            this.sec_name = b;
            this.fir_name = c;
            this.adress = d;
            this.telephone = e;
        }

        public void show_info()
        {
            Console.WriteLine("ФИО студента: {0} {1} {2}; Адрес: {3}; Телефон: {4}", this.third_name, this.sec_name, this.fir_name, this.adress, this.telephone);
        }

        public string return_fio()
        {
            string str = this.third_name + " " + this.sec_name + " " + this.fir_name;
            return str;
        }
    }

    class elective //класс факультатива
    {
        public string name;
        public int lectures;
        public int practice;
        public int lalaboratory;

        public elective(string a, int b, int c, int d)
        {
            this.name = a;
            this.lectures = b;
            this.practice = c;
            this.lalaboratory = d;
        }

        public void show_info()
        {
            Console.WriteLine("Название: {0}; Объем лекций: {1}; Объем практик: {2}; Объем лабораторных: {3}", this.name, this.lectures, this.practice, this.lalaboratory);
        }

        public string return_name()
        {
            return this.name;
        }
    }

    class plan //клас для учебного плана
    {
        public student stud;
        public elective elect;
        public int mark;

        public plan(student a, elective b, int c)
        {
            this.stud = a;
            this.elect = b;
            this.mark = c;
        }

        public void show_info()
        {
            Console.WriteLine("Студент: {0}; Предмет: {1}; Отметка: {2}", stud.return_fio(), elect.return_name(), mark);
        }
    }
    class Program
    {
        static void stud_menu(ref ArrayList list) //метод для меню ученики
        {
            int mode;
            while (true)
            {
                Console.Clear();
                mode = 0;
                Console.WriteLine("Ученики:\n[1] Список учеников\n[2] Добавить ученика\n[3] Удалить ученика\n[4] Выход");

                try
                {
                    mode = int.Parse(Console.ReadLine());
                }
                catch
                {
                    Console.WriteLine("Введено неверное значение!");
                    Console.Write("Нажмите Enter");
                    Console.ReadLine();
                }

                switch (mode)
                {
                    case 1:
                        foreach (student i in list) { i.show_info(); }
                        Console.Write("Нажмите Enter");
                        Console.ReadLine();
                        break;
                    case 2:
                        Console.WriteLine("Введите фамилию, имя, отчество, дарес и телефон:");
                        list.Add(new student(Console.ReadLine(), Console.ReadLine(), Console.ReadLine(), Console.ReadLine(), Console.ReadLine()));
                        break;
                    case 3:
                        Console.WriteLine("Введите номер ученика:");
                        try
                        {
                            mode = int.Parse(Console.ReadLine());
                            list.RemoveAt(mode - 1);
                        }
                        catch
                        {
                            Console.WriteLine("Введено неверное значение!");
                            Console.Write("Нажмите Enter");
                            Console.ReadLine();
                        }
                        break;
                    default:
                        if (mode != 4)
                        {
                            Console.WriteLine("Введено невеное значение!");
                            Console.Write("Нажмите Enter");
                            Console.ReadLine();
                        }
                        break;
                }

                if (mode == 4) { break; }
            }
        }
        static void elect_menu(ref ArrayList list) //метод для меню факультативы
        {
            int mode;
            while (true)
            {
                Console.Clear();
                mode = 0;
                Console.WriteLine("Предметы:\n[1] Список предметов\n[2] Добавить пердмет\n[3] Удалить предмет\n[4] Выход");
                try
                {
                    mode = int.Parse(Console.ReadLine());
                }
                catch
                {
                    Console.WriteLine("Введено неверное значение!");
                    Console.Write("Нажмите Enter");
                    Console.ReadLine();
                }

                switch (mode)
                {
                    case 1:
                        foreach (elective i in list) { i.show_info(); }
                        Console.Write("Нажмите Enter");
                        Console.ReadLine();
                        break;
                    case 2:
                        Console.WriteLine("Введите название, объем лекций, объем практик и объем лабораторных:");
                        list.Add(new elective(Console.ReadLine(), int.Parse(Console.ReadLine()), int.Parse(Console.ReadLine()), int.Parse(Console.ReadLine())));
                        break;
                    case 3:
                        Console.WriteLine("Введите номер пердмета:");
                        try
                        {
                            mode = int.Parse(Console.ReadLine());
                            list.RemoveAt(mode - 1);
                        }
                        catch
                        {
                            Console.WriteLine("Введено неверное значение!");
                            Console.Write("Нажмите Enter");
                            Console.ReadLine();
                        }
                        break;
                    default:
                        if (mode != 4)
                        {
                            Console.WriteLine("Введено невеное значение!");
                            Console.Write("Нажмите Enter");
                            Console.ReadLine();
                        }
                        break;
                }

                if (mode == 4) { break; }
            }
        }

        static void set_plan(ref ArrayList main_list, ArrayList stud, ArrayList elect) //метод для меню составления учебного плана
        {
            int mode;
            while (true)
            {
                Console.Clear();
                mode = 0;
                Console.WriteLine("Учебный план:\n[1] Вывести учебный план\n[2] Соотнести ученика и факультатив\n[3] Удалить соотношение\n[4] Выход");
                try
                {
                    mode = int.Parse(Console.ReadLine());
                }
                catch
                {
                    Console.WriteLine("Введено неверное значение!");
                }

                switch (mode)
                {
                    case 1:
                        foreach (plan i in main_list) { i.show_info(); }
                        Console.Write("Нажмите Enter");
                        Console.ReadLine();
                        break;
                    case 2:
                        Console.WriteLine("Ученики:");
                        foreach (student i in stud) { i.show_info(); }
                        Console.WriteLine("\nПердметы:");
                        foreach (elective i in elect) { i.show_info(); }
                        Console.WriteLine("\nВведите номер ученика, номер факультатива и отметку:");
                        try
                        {
                            int a = int.Parse(Console.ReadLine());
                            int b = int.Parse(Console.ReadLine());
                            int c = int.Parse(Console.ReadLine());
                            if ((c > 10) || (c < 0))
                            {
                                Console.WriteLine("Введена недопустимая отметка!");
                            }
                            else
                            {
                                main_list.Add(new plan((student)stud[a - 1], (elective)elect[b - 1], c));
                            }
                        }
                        catch
                        {
                            Console.WriteLine("Введено неверное значение!");
                        }
                        break;
                    case 3:
                        Console.WriteLine("Введите номер соотношения:");
                        try
                        {
                            mode = int.Parse(Console.ReadLine());
                            main_list.RemoveAt(mode - 1);
                        }
                        catch
                        {
                            Console.WriteLine("Введено неверное значение!");
                            Console.Write("Нажмите Enter");
                            Console.ReadLine();
                        }
                        break;
                    default:
                        if (mode != 4)
                        {
                            Console.WriteLine("Введено невеное значение!");
                            Console.Write("Нажмите Enter");
                            Console.ReadLine();
                        }
                        break;
                }

                if (mode == 4) { break; }
            }
        }
        static void Main(string[] args)
        {
            ArrayList students = new ArrayList(); //список учеников
            students.Add(new student("Кормильчик", "Дмитрий", "Витальевич", "Новооктябрьская 14", "2-54-32"));
            students.Add(new student("Геласевич", "Олег", "Дмитревиич", "Новооктябрьская 16", "2-57-88"));
            students.Add(new student("Октанович", "Александра", "Васильевна", "Горновых 5", "2-34-74"));

            ArrayList electives = new ArrayList(); //список для факультативов
            electives.Add(new elective("Физика", 20, 5, 3));
            electives.Add(new elective("Математика", 25, 7, 2));

            ArrayList planList = new ArrayList(); //список для учебного плана
            int mode;

            while (true) //основное меню
            {
                Console.Clear();
                mode = 0;
                Console.WriteLine("Главное меню:\n[1] Ученики\n[2] Предметы\n[3] Учебный план\n[4] Выход");
                try
                {
                    mode = int.Parse(Console.ReadLine());
                }
                catch
                {
                    Console.WriteLine("Введено неверное значение!");
                    Console.Write("Нажмите Enter");
                    Console.ReadLine();
                }

                switch (mode)
                {
                    case 1:
                        stud_menu(ref students);
                        break;
                    case 2:
                        elect_menu(ref electives);
                        break;
                    case 3:
                        set_plan(ref planList, students, electives);
                        break;
                    case 4:
                    default:
                        if (mode != 4)
                        {
                            Console.WriteLine("Введено невеное значение!");
                            Console.Write("Нажмите Enter");
                            Console.ReadLine();
                        }
                        break;
                }

                if (mode == 4) { break; }
            }
        }
    }
}
