﻿using System;

namespace L3Z1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите числа, в диапазоне которых будет проводиться расчёт (a <= b)");
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите 2 цифры, которые будем искать на конце чисел");
            int x = int.Parse(Console.ReadLine());
            int y = int.Parse(Console.ReadLine());
            for (int i = a; i < b; i++)
                if ((i - x) % 10 == 0 || (i - y) % 10 == 0)
                    Console.WriteLine(i);
        }
    }
}
