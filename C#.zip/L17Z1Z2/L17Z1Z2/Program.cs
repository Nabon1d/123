﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab17._1
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.Write("Введите выражение: ");
                Console.WriteLine(Polish.Calculate(Console.ReadLine()));
            }
        }
    }
    class Polish
    {
        static public double Calculate(string input)
        {
            var tokens = new Queue<string>(input.Split());
            string output = GetExpression(tokens);
            Console.WriteLine(output);
            string reverse_input = new string(input.ToCharArray().Reverse().ToArray());
            Console.WriteLine(reverse_input);
            double result = Counting(reverse_input);
            Console.WriteLine("Результат:");
            return result;
        }
        private static string[] operators = new string[] { "+", "-", "*", "/" };
        static private string GetExpression(Queue<string> tokens)
        {
            var token = tokens.Dequeue();
            if (operators.Contains(token))
            {
                return String.Format("({0} {1} {2})", GetExpression(tokens), token, GetExpression(tokens));
            }
            else
            {
                return token;
            }
        }

        public static double Counting(string input)
        {
            double result = 0;
            Stack<double> temp = new Stack<double>();

            for (int i = 0; i < input.Length; i++)
            {
                if (Char.IsDigit(input[i]))
                {
                    string a = string.Empty;

                    while (!IsDelimeter(input[i]) && !IsOperator(input[i]))
                    {
                        a += input[i];
                        i++;
                        if (i == input.Length) break;
                    }
                    temp.Push(double.Parse(a));
                    i--;
                }
                else if (IsOperator(input[i]))
                {
                    double a = temp.Pop();
                    double b = temp.Pop();

                    switch (input[i])
                    {
                        case '+': result = a + b; break;
                        case '-': result = a - b; break;
                        case '*': result = a * b; break;
                        case '/': result = a / b; break;
                        case '^': result = double.Parse(Math.Pow(double.Parse(b.ToString()), double.Parse(a.ToString())).ToString()); break;
                    }
                    temp.Push(result);
                }
            }
            return temp.Peek();
        }
        static private bool IsOperator(char с)
        {
            if (("+-/*^()".IndexOf(с) != -1))
            {
                return true;
            }
            return false;
        }
        static private bool IsDelimeter(char c)
        {
            if ((" =".IndexOf(c) != -1))
            {
                return true;
            }
            return false;
        }
    }
}