﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ConsoleApplication5
{
    class Program
    {
        static void Main(string[] args)
        {
            string s = File.ReadAllText(@"D:\T1.txt");
            List<string> listString = new List<string>();

            int count = 0;
            int last, first;
            first = 0;
            for (var i = 0; i < s.Length; i++)
            {
                if (s[i] == ';' || count == 30)
                {
                    last = i;
                    listString.Add(s.Substring(first, last - first));
                    first = last;
                    count = 0;
                }
                else if (s[i] != ' ' && s[i] != ',' && s[i] != '.' && s[i] != '!' && s[i] != '?') count++;

            }


            FileStream file1 = new FileStream(@"D:\\T2.txt ", FileMode.Create); //создаем файловый поток
            StreamWriter writer = new StreamWriter(file1); //создаем «потоковый писатель» и связываем егoс файловым потоком 
                foreach (var a in listString)
                {
                    string b = a;
                    writer.Write(b);
                    writer.Write("\n");
                }
                
            writer.Close(); //закрываем поток. Не закрыв поток, в файл ничего не запишется
            Console.ReadKey();


        }
    }
}